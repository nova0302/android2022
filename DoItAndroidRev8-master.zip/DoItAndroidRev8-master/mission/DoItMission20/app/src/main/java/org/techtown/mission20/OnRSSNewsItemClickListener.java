package org.techtown.mission20;

import android.view.View;

public interface OnRSSNewsItemClickListener {
    public void onItemClick(RSSNewsAdapter.ViewHolder holder, View view, int position);
}
