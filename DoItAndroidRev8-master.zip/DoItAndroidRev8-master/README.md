# DoItAndroid
Do it! 안드로이드 앱 프로그래밍(개정8판)의 소스 코드

# 설명

 - part1, part2, part3으로 나누어져 있으며 각각 첫째마당, 둘째마당, 셋째마당을 위한 폴더입니다.
 - 각 폴더에는 chapter01, chapter02와 같이 각 장(chapter)에 맞는 폴더들이 들어 있습니다.
 - 소스를 다운로드한 후 압축을 풀고 안드로이드 스튜디오에서 [Open an existing Android Studio project] 메뉴를 누르면 각 장을 위한 폴더 아래에 있는 각각의 프로젝트 폴더를 지정하여 열 수 있습니다.
 
